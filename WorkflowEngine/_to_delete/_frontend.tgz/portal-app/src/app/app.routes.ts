import { Routes } from '@angular/router';
import { authGuard, createGuard, moduleGuard, permGuard } from './core/auth.guard';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: 'login', loadComponent: () => import('./login/login.component').then(m => m.LoginComponent) },
  { path: 'dashboard', canActivate: [authGuard, permGuard('dashboard.view')], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'm/:module', canActivate: [authGuard, moduleGuard], loadComponent: () => import('./modules/module.component').then(m => m.ModuleComponent) },
  { path: 'new/:docType', canActivate: [authGuard, createGuard], loadComponent: () => import('./documents/doc-form.component').then(m => m.DocFormComponent) },
  { path: 'approvals', canActivate: [authGuard, permGuard('tasks.act')], loadComponent: () => import('./tasks/tasks.component').then(m => m.TasksComponent) },
  { path: 'documents', canActivate: [authGuard], loadComponent: () => import('./requests/requests.component').then(m => m.RequestsComponent) },
  { path: 'documents/:id', canActivate: [authGuard], loadComponent: () => import('./requests/request-detail.component').then(m => m.RequestDetailComponent) },
  { path: 'services', canActivate: [authGuard], loadComponent: () => import('./submit/submit.component').then(m => m.SubmitComponent) },
  { path: 'reports', canActivate: [authGuard, permGuard('reports.view')], loadComponent: () => import('./reports/reports.component').then(m => m.ReportsComponent) },
  { path: 'assistant', canActivate: [authGuard, permGuard('assistant.use')], loadComponent: () => import('./assistant/assistant-page.component').then(m => m.AssistantPageComponent) },

  { path: 'admin', canActivate: [authGuard, permGuard('admin.users', 'org.manage')], loadComponent: () => import('./admin/admin.component').then(m => m.AdminComponent) },

  // old portal URLs keep working
  { path: 'submit', redirectTo: 'services' },
  { path: 'tasks', redirectTo: 'approvals' },
  { path: 'requests', redirectTo: 'documents' },
  { path: 'requests/:id', redirectTo: 'documents/:id' },
  { path: '**', redirectTo: 'dashboard' },
];
